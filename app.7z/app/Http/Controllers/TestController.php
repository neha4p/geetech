<?php namespace App\Http\Controllers;

class TestController extends Controller
{

    public function __construct()
    {
        //
    }

    /*
	|--------------------------------------------------------------------------
	| Home Controller
	|--------------------------------------------------------------------------
	*/

    public function index()
    {

        echo 'test';
    }
}
