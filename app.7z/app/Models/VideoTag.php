<?php

class VideoTag extends Eloquent
{

    protected $table = 'tag_video';
    protected $guarded = [];

    public static $rules = [];
}
