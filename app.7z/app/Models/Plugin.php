<?php

class Plugin extends Eloquent
{

    protected $guarded = [];
    public static $rules = [];
}
