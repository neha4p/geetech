<?php
class PluginData extends Eloquent
{
    protected $table = 'plugin_data';
    protected $guarded = [];
    public static $rules = [];
}
